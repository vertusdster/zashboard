export default {
  plugins: {
    'postcss-for': {},
    'postcss-calc': {},
    tailwindcss: {},
    autoprefixer: {},
  },
}
