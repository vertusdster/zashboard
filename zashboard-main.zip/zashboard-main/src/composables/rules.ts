import { RULE_TAB_TYPE } from '@/constant'
import { ref } from 'vue'

export const rulesTabShow = ref(RULE_TAB_TYPE.RULES)
